﻿【Where is my weapon?】
・気絶から回復した際、気絶前に持っていた武器を装備しなおそうとします。


■更新履歴
[2019/01/11]繁体字中国語に対応
・繁体字中国語訳を追加(btx7812氏)

[2018/11/05]ロシア語に対応
・ロシア語訳を追加(x626384315253x氏)

[2018/10/22]スペイン語に対応
・スペイン語訳を追加(Pollo frito氏)
・バグを修正

[2018/10/21a]バグを修正
・バグを修正

[2018/10/21]フランス語に対応
・フランス語訳を追加(«ⓌⓎⓋⒺⓇⓃ»氏)

[2018/10/14]1.0に対応
・1.0開発版(1.0.2056)に対応（多分正式版も動く）
・ダウンから復帰し装備し直そうとする前に再度ダウンすると、装備しなくなるバグを修正

[2018/08/27]B19に対応
・B19開発版(0.19.2006)に対応（正式版でも動けばいいな）

[2018/07/01]1.0に対応
・1.0開発版(1.0.1950)に対応（多分正式版も動く）
・落とした装備を装備してから、落とした物を拾うように変更

[2018/05/17]韓国語に対応
・韓国語訳を追加(Orange Mushroom氏)

[2018/01/10]ポーランド語に対応
・ポーランド語を追加(乞食Strzig??氏)

[2017/12/26]バグの修正？
・バグが起こる可能性がある箇所を修正

[2017/12/22]公開


■その他
質問、不具合などがあれば、Twitter(@tammybee_tmb)か以下のページのコメント欄、SteamWorkshopにて報告をお願いします。

・民火MOD | RimWorld私的wiki
http://seesaawiki.jp/rimworld/d/%cc%b1%b2%d0%20MOD

このMODはHarmony Patch Libraryを使用しています。

・Harmonyスレッド | Ludeonフォーラム
https://ludeon.com/forums/index.php?topic=29517.0


■ライセンス
このMODはCC-BY-NC-SA 4.0 国際 ライセンスとMIT Licenseのもと、配布をしています。

This mod is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License and MIT license.

Copyright 2017 TammyBee