# RT_Fuse
RimWorld mod; see [About.xml](../master/About/About.xml) and [forum thread](https://ludeon.com/forums/index.php?topic=11272).
