﻿using System.Reflection;
using Bubbles;

[assembly: AssemblyTitle(Mod.Name)]
[assembly: AssemblyProduct("RimWorld Mods by Jaxe")]
[assembly: AssemblyCopyright("© Jaxe")]
[assembly: AssemblyVersion(Mod.Version)]
