﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace GiddyUpCore.Jobs
{
    [DefOf]
    public static class GUC_JobDefOf
    {
        public static JobDef Mount;
        public static JobDef Mounted;
        public static JobDef Dismount; 
    }

}
