﻿namespace CompVehicle
{
    public static class StringOf
    {
        public static string pilot = "pilot";
        public static string gunner = "gunner";
        public static string crew = "crew";
        public static string passenger = "passenger";
        public static string Pilots = "Pilots";
        public static string Gunners = "Gunners";
        public static string Crew = "Crew";
        public static string Passengers = "Passngers";
        public static string Disabled = "Disabled";
        public static string Inoperable = "Inoperable";
        public static string Operational = "Operational";
        public static string Movement = "Movement Systems";
        public static string Manipulation = "Manipulation Systems";
        public static string Weapons = "Weapon Systems";
        public static string On = "Online";
        public static string Off = "Offline";
        public static string MessageCriticalHit = "{0} landed a critical hit on {1} {2}.";
    }
}