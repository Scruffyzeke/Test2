﻿using System;
using RimWorld;
namespace CompVehicle
{
    //WIP
	[DefOf]
	public static class SiteDefOfVehicles
	{
		public static SiteCoreDef AbandonedVehicles;
		public static SitePartDef Vehicles;
		public static WorldObjectDef ABDVehicles;
	}
}
