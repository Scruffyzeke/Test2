using System.Collections.Generic;
using Verse;
using Verse.AI;

namespace JecsTools
{
    
    public class BuildingExtension : DefModExtension
    {
        public List<string> wipeCategories = new List<string>();
    }
}