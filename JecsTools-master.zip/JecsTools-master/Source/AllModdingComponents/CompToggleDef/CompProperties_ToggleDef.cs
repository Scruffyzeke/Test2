using Verse;

namespace CompToggleDef
{
    public class CompProperties_ToggleDef : CompProperties
    {
        public string labelKey;

        public CompProperties_ToggleDef()
        {
            compClass = typeof(CompToggleDef);
        }
    }
}