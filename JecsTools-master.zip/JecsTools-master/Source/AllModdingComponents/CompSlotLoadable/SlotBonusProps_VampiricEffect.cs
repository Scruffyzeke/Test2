﻿namespace CompSlotLoadable
{
    public class SlotBonusProps_VampiricEffect
    {
        public float chance = 0.05f;
        public int woundLimit = 0;
    }
}