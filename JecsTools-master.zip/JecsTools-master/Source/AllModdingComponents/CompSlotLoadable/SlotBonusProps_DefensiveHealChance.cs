﻿namespace CompSlotLoadable
{
    public class SlotBonusProps_DefensiveHealChance
    {
        public float chance = 0.05f;
        public int woundLimit = 0;
    }
}