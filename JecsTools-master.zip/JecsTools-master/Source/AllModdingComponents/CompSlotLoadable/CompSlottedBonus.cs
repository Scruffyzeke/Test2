﻿using Verse;

namespace CompSlotLoadable
{
    public class CompSlottedBonus : ThingComp
    {
        public CompProperties_SlottedBonus Props => (CompProperties_SlottedBonus) props;
    }
}