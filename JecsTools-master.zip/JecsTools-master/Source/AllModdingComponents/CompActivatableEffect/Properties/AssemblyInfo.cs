﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CompActivatableEffect")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CompActivatableEffect")]
[assembly: AssemblyCopyright("Copyright © Jecrell 2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("ec1aea45-45fe-4a6a-a835-81b289e03bc9")]

[assembly: AssemblyVersion("1.18.0.0")]
[assembly: AssemblyFileVersion("1.18.0.0")]