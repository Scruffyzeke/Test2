﻿using RimWorld;
using Verse;

namespace AbilityUser
{
    [DefOf]
    public static class AbilityDefOf
    {
        public static JobDef CastAbilitySelf;
        public static JobDef CastAbilityVerb;
    }
}