﻿using Verse;

namespace AbilityUser
{
    public class CompProperties_AbilityUser : CompProperties
    {
        public CompProperties_AbilityUser()
        {
            compClass = typeof(CompAbilityUser);
        }
    }
}