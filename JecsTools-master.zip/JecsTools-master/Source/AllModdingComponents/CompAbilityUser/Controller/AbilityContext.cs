﻿namespace AbilityUser
{
    public enum AbilityContext
    {
        Player,
        AI
    }
}