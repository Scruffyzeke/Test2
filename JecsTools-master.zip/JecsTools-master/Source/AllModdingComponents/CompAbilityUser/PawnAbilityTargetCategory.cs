﻿namespace AbilityUser
{
    public enum AbilityTargetCategory
    {
        TargetSelf,
        TargetThing,
        TargetLocation,
        TargetAoE
    }
}