﻿using RimWorld;
using Verse;

namespace CompDeflector
{
    [DefOf]
    public static class CompDeflectorDefOf
    {
        public static JobDef CastDeflectVerb;
    }
}