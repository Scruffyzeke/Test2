﻿using Verse;

namespace CompExtraSounds
{
    internal class CompExtraSounds : ThingComp
    {
        public CompProperties_ExtraSounds Props => (CompProperties_ExtraSounds) props;
    }
}