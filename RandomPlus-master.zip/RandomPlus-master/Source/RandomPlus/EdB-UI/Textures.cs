﻿using RimWorld;
using System;
using UnityEngine;
using Verse;

namespace RandomPlus {
    [StaticConstructorOnStartup]
    public static class Textures {
        private static bool loaded = false;

        public static Texture2D TexturePassionMajor;
        public static Texture2D TexturePassionMinor;
        public static Texture2D TextureFieldAtlas;
        public static Texture2D TexturePortraitBackground;
        public static Texture2D TextureButtonPrevious;
        public static Texture2D TextureButtonNext;
        public static Texture2D TextureButtonRandom;
        public static Texture2D TextureButtonRandomLarge;
        public static Texture2D TexturePassionNone;
        public static Texture2D TextureButtonDelete;
        public static Texture2D TextureButtonDeleteTab;
        public static Texture2D TextureButtonDeleteTabHighlight;
        public static Texture2D TextureButtonGenderFemale;
        public static Texture2D TextureButtonGenderMale;
        public static Texture2D TextureButtonReset;
        public static Texture2D TextureButtonClearSkills;
        public static Texture2D TextureDropdownIndicator;
        public static Texture2D TextureAlert;
        public static Texture2D TextureAlertSmall;
        public static Texture2D TextureDerivedRelationship;
        public static Texture2D TextureButtonAdd;
        public static Texture2D TextureRadioButtonOff;
        public static Texture2D TextureDeleteX;
        public static Texture2D TextureAlternateRow;
        public static Texture2D TextureSkillBarFill;
        public static Texture2D TextureSortAscending;
        public static Texture2D TextureSortDescending;
        public static Texture2D TextureTabAtlas;
        public static Texture2D TextureButtonBGAtlas;
        public static Texture2D TextureButtonBGAtlasMouseover;
        public static Texture2D TextureButtonBGAtlasClick;
        public static Texture2D TextureArrowLeft;
        public static Texture2D TextureArrowRight;
        public static Texture2D TextureArrowDown;
        public static Texture2D TextureGenderFemaleLarge;
        public static Texture2D TextureGenderMaleLarge;
        public static Texture2D TextureGenderlessLarge;
        public static Texture2D TextureButtonInfo;
        public static Texture2D TextureCheckbox;
        public static Texture2D TextureCheckboxSelected;
        public static Texture2D TextureCheckboxPartiallySelected;
        public static Texture2D TextureDottedLine;

        static Textures() {
            LoadTextures();
        }

        public static bool Loaded {
            get {
                return loaded;
            }
        }

        public static void Reset() {
            LongEventHandler.ExecuteWhenFinished(() => {
                LoadTextures();
            });
        }

        private static void LoadTextures() {
            loaded = false;
            TexturePassionMajor = ContentFinder<Texture2D>.Get("UI/Icons/PassionMajor", true);
            TexturePassionMinor = ContentFinder<Texture2D>.Get("UI/Icons/PassionMinor", true);
            TextureRadioButtonOff = ContentFinder<Texture2D>.Get("UI/Widgets/RadioButOff", true);
            TexturePortraitBackground = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/CharMakerPortraitBG", true);
            TextureFieldAtlas = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/FieldAtlas", true);
            TextureButtonPrevious = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonPrevious", true);
            TextureButtonNext = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonNext", true);
            TextureButtonRandom = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonRandom", true);
            TextureButtonRandomLarge = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonRandomLarge", true);
            TexturePassionNone = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/NoPassion", true);
            TextureButtonDelete = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonDelete", true);
            TextureButtonDeleteTab = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonDeleteTab", true);
            TextureButtonDeleteTabHighlight = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonDeleteTabHighlight", true);
            TextureButtonGenderFemale = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonGenderFemale", true);
            TextureButtonGenderMale = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonGenderMale", true);
            TextureButtonReset = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonReset", true);
            TextureButtonClearSkills = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonClear", true);
            TextureDropdownIndicator = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/DropdownIndicator", true);
            TextureAlert = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/Alert", true);
            TextureAlertSmall = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/AlertSmall", true);
            TextureDerivedRelationship = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/DerivedRelationship", true);
            TextureButtonAdd = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ButtonAdd", true);
            TextureDeleteX = ContentFinder<Texture2D>.Get("UI/Buttons/Delete", true);
            TextureSortAscending = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/SortAscending", true);
            TextureSortDescending = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/SortDescending", true);
            TextureArrowLeft = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ArrowLeft", true);
            TextureArrowRight = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ArrowRight", true);
            TextureArrowDown = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/ArrowDown", true);
            TextureGenderFemaleLarge = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/GenderFemaleLarge", true);
            TextureGenderMaleLarge = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/GenderMaleLarge", true);
            TextureGenderlessLarge = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/GenderlessLarge", true);
            TextureCheckbox = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/Checkbox", true);
            TextureCheckboxSelected = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/CheckboxSelected", true);
            TextureCheckboxPartiallySelected = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/CheckboxPartiallySelected", true);
            TextureDottedLine = ContentFinder<Texture2D>.Get("EdB/PrepareCarefully/DottedLine", true);

            TextureTabAtlas = ContentFinder<Texture2D>.Get("UI/Widgets/TabAtlas", true);

            TextureButtonBGAtlas = ContentFinder<Texture2D>.Get("UI/Widgets/ButtonBG", true);
            TextureButtonBGAtlasMouseover = ContentFinder<Texture2D>.Get("UI/Widgets/ButtonBGMouseover", true);
            TextureButtonBGAtlasClick = ContentFinder<Texture2D>.Get("UI/Widgets/ButtonBGClick", true);
            TextureButtonInfo = ContentFinder<Texture2D>.Get("UI/Buttons/InfoButton", true);

        TextureAlternateRow = SolidColorMaterials.NewSolidColorTexture(new Color(1, 1, 1, 0.05f));
            TextureSkillBarFill = SolidColorMaterials.NewSolidColorTexture(new Color(1f, 1f, 1f, 0.1f));

            loaded = true;
        }
    }
}

