# RandomPlus
A Rimworld mod for auto rerolling pawns to match a user set specification.

![Main Image](./About/main.png)

## Credits
* __edbmods__ for UI code and assets forked from [EdBPrepareCarefully mod](https://github.com/edbmods/EdBPrepareCarefully)