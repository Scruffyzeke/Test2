﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

//LEGACY CODE: This is included to ensure compatibility with old saves, up to date files have been moved to Giddy-up Core. 

namespace BattleMounts.Jobs
{
    [DefOf]
    public static class BM_JobDefOf
    {
        public static JobDef Mount_BattleMount;
        public static JobDef Mounted_BattleMount;

    }

}
