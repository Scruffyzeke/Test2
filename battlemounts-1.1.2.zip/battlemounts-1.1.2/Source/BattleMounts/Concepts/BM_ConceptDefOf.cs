﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Battlemounts.Concepts
{
    [DefOf]
    class BM_ConceptDefOf
    {
        public static ConceptDef BM_Mounting;
        public static ConceptDef BM_Enemy_Mounting;
    }
}
