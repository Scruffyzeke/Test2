# Giddy-up! Battlemounts

## Dependencies

Depends on Giddy-up! Core, and Hugslib. Load order should be HugsLib->Giddy-up Core->Giddy-up! Battle Mounts

## Install

Download the zip from one of the releases, unpack and place the unpacked folder in the Rimworld mods folder. 

## Contributing

Translations are always very welcome. Just create a pull request, preferably in the development branch. 

## Licence
Feel free to add this mod to modpacks or to use the code or icons for other projects. 
Do however not release exact copies of my project, or exact copies with minor adjustments without my consent.
Code is derivate from Ludeon Studio.
